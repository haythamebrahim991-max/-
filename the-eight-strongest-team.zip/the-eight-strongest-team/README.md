# The eight strongest team 

A Pen created on CodePen.

Original URL: [https://codepen.io/Haytham-Ebrahim/pen/raWjOeO](https://codepen.io/Haytham-Ebrahim/pen/raWjOeO).

